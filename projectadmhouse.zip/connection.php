<?php
$con = mysqli_connect("localhost", "root", "", "home")or die(mysqli_error());
?>