<?php

include('header.php');




?>

<div class="container">

<h1>Desenvolvido por:</h1>
<p>Victor Dias Caselli Porto</p>

<h1>Objetivos</h1>
<p>Este Web App tem como objetivo facilitar a lista de compras no mercado, dando assim ferramentas que 
    desenvolvem lista de compras ou um estoque pessoal.
</p>






</div>

<?php
include('footer.php');

?>